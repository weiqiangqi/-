//
//  AppDelegate.h
//  仿知乎图文混排效果
//
//  Created by andun on 16/8/6.
//  Copyright © 2016年 齐伟强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

