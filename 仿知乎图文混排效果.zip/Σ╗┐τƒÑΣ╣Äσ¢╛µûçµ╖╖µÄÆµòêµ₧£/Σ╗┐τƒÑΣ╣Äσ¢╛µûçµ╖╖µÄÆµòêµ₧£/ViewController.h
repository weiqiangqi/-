//
//  ViewController.h
//  仿知乎图文混排效果
//
//  Created by andun on 16/8/6.
//  Copyright © 2016年 齐伟强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)addPicAction:(id)sender;//添加图片按钮事件
- (IBAction)overAction:(id)sender;//完成按钮事件

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

