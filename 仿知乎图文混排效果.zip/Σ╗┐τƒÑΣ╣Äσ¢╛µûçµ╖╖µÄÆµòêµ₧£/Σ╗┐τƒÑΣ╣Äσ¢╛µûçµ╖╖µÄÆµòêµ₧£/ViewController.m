//
//  ViewController.m
//  仿知乎图文混排效果
//
//  Created by andun on 16/8/6.
//  Copyright © 2016年 齐伟强. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property(nonatomic,strong)NSMutableDictionary *mutImgDict;
@property(nonatomic,strong)NSMutableArray *mutImgArray;
@property(nonatomic,strong)NSMutableArray *imgArray;//最终确定照片URl数组
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addPicAction:(id)sender {
    UIImagePickerController *imgPicker = [UIImagePickerController new];
    imgPicker.delegate = self;
    imgPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:imgPicker animated:YES completion:nil];
}
//生成文本  包含了图片地址链接  可以直接传给后台制作HTML页面
- (IBAction)overAction:(id)sender {
    NSString *textStr = [[self textStringWithSymbol:@"[图片]" attributeString:_textView.attributedText] mutableCopy];
    int index = 0;
    //通过替换
    for (int i = 0; i <= textStr.length - 4; i ++) {
        NSString *tempStr = [textStr substringWithRange:NSMakeRange(i, 4)];
        if ([tempStr isEqualToString:@"[图片]"]) {
            NSString *imgStr = [NSString stringWithFormat:@"<img src = '%@'/>",self.imgArray[index]];
            textStr = [textStr stringByReplacingCharactersInRange:NSMakeRange(i, 4) withString:imgStr];
            index ++;
        }
    }
}
#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self dismissViewControllerAnimated:YES completion:^{
        UIImage * img = [info objectForKey:UIImagePickerControllerOriginalImage];
        [self uploadPicture:img];
        NSTextAttachment* textAttachment = [[NSTextAttachment alloc] init];
        textAttachment.image = img;
        textAttachment.bounds = CGRectMake(0, 0, self.view.frame.size.width - 28, [self getImgHeightWithImg:img]);
        NSAttributedString* imageAttachment = [NSAttributedString attributedStringWithAttachment:textAttachment];
        NSMutableAttributedString *attriStr = [_textView.attributedText mutableCopy];
        [attriStr appendAttributedString:imageAttachment];
        _textView.attributedText = attriStr;
    }];
}
//取消回调
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:^{
        [_textView becomeFirstResponder];
    }];
}
//上传照片
- (void)uploadPicture:(UIImage *)image
{
    //此处是上传单张图片   ------ 等上传成功后按照下面去存储数据
    /*
            NSDictionary *rawDic = (NSDictionary *)responseObject;
            NSDictionary *infoDic = [rawDic objectForKey:@"info"];
            
            NSString *url = [infoDic valueForKey:@"url"];
            [self.mutImgDict setValue:image forKey:url];
            [self.textView becomeFirstResponder];
    */
}
//根据屏幕宽度适配高度
- (CGFloat)getImgHeightWithImg:(UIImage *)img
{
    CGFloat height = ((self.view.frame.size.width - 28)/ img.size.width) * img.size.height;
    return height;
}

#pragma mark - 富文本转换操作
/** 将富文本转换为带有图片标志的纯文本*/
- (NSString *)textStringWithSymbol:(NSString *)symbol attributeString:(NSAttributedString *)attributeString{
    NSString *string = attributeString.string;
    string = [self stringDeleteString:@"\n" frontString:@"[图片]" inString:string];
    //最终纯文本
    NSMutableString *textString = [NSMutableString stringWithString:string];
    //替换下标的偏移量
    __block NSUInteger base = 0;
    
    //遍历
    [attributeString enumerateAttribute:NSAttachmentAttributeName inRange:NSMakeRange(0, attributeString.length)
                                options:0
                             usingBlock:^(id value, NSRange range, BOOL *stop) {
                                 //检查类型是否是自定义NSTextAttachment类
                                 if (value && [value isKindOfClass:[NSTextAttachment class]]) {
                                     //替换
                                     [textString replaceCharactersInRange:NSMakeRange(range.location + base, range.length) withString:symbol];
                                     //增加偏移量
                                     base += (symbol.length - 1);
                                     //将富文本中最终确认的照片取出来
                                     NSTextAttachment *attachmentImg = (NSTextAttachment *)value;
                                     [self.mutImgArray addObject:attachmentImg.image];
                                 }
                             }];
    //-------------- 最后点击完成事件时 通过对比将富文本中最终确定的照片审选出来 找到对应照片的URl地址
    NSArray *keyArray = [self.mutImgDict allKeys];
    
    for (int i = 0; i < _mutImgArray.count; i ++) {
        UIImage *img = _mutImgArray[i];
        for (int j = 0; j < keyArray.count; j ++) {
            UIImage *myImg = [self.mutImgDict valueForKey:keyArray[j]];
            if (myImg == img) {
                [self.imgArray addObject:keyArray[j]];
            }
        }
    }
    //--------------
    return textString;
}
/** 删除字符串*/
- (NSString *)stringDeleteString:(NSString *)deleteString frontString:(NSString *)frontString inString:(NSString *)inString{
    NSArray *ranges = [self rangeOfSymbolString:frontString inString:inString];
    NSMutableString *mutableString = [inString mutableCopy];
    NSUInteger base = 0;
    for (NSString *rangeString in ranges) {
        NSRange range = NSRangeFromString(rangeString);
        [mutableString deleteCharactersInRange:NSMakeRange(range.location - deleteString.length + base, deleteString.length)];
        base -= deleteString.length;
    }
    return [mutableString copy];
}
/** 统计文本中所有图片资源标志的range*/
- (NSArray *)rangeOfSymbolString:(NSString *)symbol inString:(NSString *)string {
    NSMutableArray *rangeArray = [NSMutableArray array];
    NSString *string1 = [string stringByAppendingString:symbol];
    NSString *temp;
    for (int i = 0; i < string.length; i ++) {
        temp = [string1 substringWithRange:NSMakeRange(i, symbol.length)];
        if ([temp isEqualToString:symbol]) {
            NSRange range = {i, symbol.length};
            [rangeArray addObject:NSStringFromRange(range)];
        }
    }
    return rangeArray;
}

#pragma mark - 懒加载
- (NSMutableArray *)mutImgArray
{
    if (!_mutImgArray) {
        _mutImgArray = [NSMutableArray array];
    }
    return _mutImgArray;
}
- (NSMutableDictionary *)mutImgDict
{
    if (!_mutImgDict) {
        _mutImgDict = [NSMutableDictionary dictionary];
    }
    return _mutImgDict;
}
-(NSMutableArray *)imgArray
{
    if (!_imgArray) {
        _imgArray = [NSMutableArray array];
    }
    return _imgArray;
}

@end
