//
//  main.m
//  仿知乎图文混排效果
//
//  Created by andun on 16/8/6.
//  Copyright © 2016年 齐伟强. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
